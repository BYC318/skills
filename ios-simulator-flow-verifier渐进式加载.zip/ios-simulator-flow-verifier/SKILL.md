---
name: ios-simulator-flow-verifier
description: 通过 xcodebuild、simctl、XCTest/XCUITest、无障碍标识符、确定性测试数据、接口契约测试、无障碍审计、截图、日志和 xcresult 证据，构建、安装、启动、操作并验证 iOS 应用的真实模拟器流程。适用于修改 Swift、SwiftUI、UIKit、导航、状态、网络、持久化、权限或界面行为之后；用户要求运行或点击验证 iOS 流程时；诊断“编译成功但运行不起来”时；以及任何不能只靠编译来证明正确性的场景。
---

# iOS 模拟器流程验证

把模拟器验证作为验收门槛，而不是启动演示。绝不能把编译成功等同于功能正确。

## 核心结果

为下面的完整证据链提供证明：

```text
源码修改
→ 编译成功
→ 应用安装并启动
→ 通过语义定位真实控件
→ 执行用户业务旅程
→ 断言可见状态和持久化状态
→ 必要时断言请求与响应契约
→ 无障碍检查通过
→ 报告 xcresult、截图和运行时证据
```

## 每次验证都从这里开始

1. 先读取仓库说明，并优先使用仓库规定的代码发现工具。
2. 确认 `.xcworkspace` 或 `.xcodeproj`、应用 Scheme、测试 Target、Bundle Identifier、最低系统版本和当前模拟器清单。
3. 把代码改动转换为可观察的验收条件。按需包含成功流程、权限差异、数据修改结果、刷新或持久化行为、空状态、错误状态和导航目标。
4. 新增测试模式前，先检查项目现有的单元测试、契约测试和 UI 测试写法。
5. 优先使用已经启动且兼容的模拟器。不得在源码或 Skill 中写死模拟器 UUID。
6. 用户正在本机观察验证过程时使用默认可视模式。即使设备已经 Booted，也必须打开并置前 Simulator，且测试开始前可见窗口对应的基础设备 UUID 必须与测试 Destination 完全一致。并行测试开始后，Xcode 创建的 Clone 使用独立临时 UUID，不属于不一致。

使用 `scripts/verify_ios_flow.sh --help` 查看确定性命令执行器。能调用 XcodeBuildMCP 或模拟器工具时优先使用；否则使用本脚本和 `xcrun simctl`。

验证范围必须由当前代码改动、产品验收条件和仓库现有测试体系共同决定。不得因为某个历史项目或示例，默认要求所有项目具备特定页面、业务名词、容器、SDK 或外部服务。遇到网页容器、支付、推送、媒体、地图等专项能力时，只在当前任务内读取项目实现并设计对应测试；不要把专项规则永久写回本通用 Skill。

## 设计可测试边界

让 UI 控件可以脱离坐标进行定位：

```swift
.accessibilityIdentifier("profile.save")
```

操作、输入框、列表行和有状态控件应使用稳定且带命名空间的标识符。可见文字可以本地化；在能提供标识符时，不得只依赖英文标题定位控件。

通过启动参数或依赖注入的 Gateway 提供确定性的非生产测试数据。测试数据必须支持状态修改，不能只返回静态截图。切换、购买、关注或保存操作必须改变测试状态，随后刷新时必须能够读到修改结果。

不得为了让 UI 测试通过而绕开生产环境的导航或状态层。继续使用相同的页面、Store、路由和用例代码；只替换网络、实时通信、支付、媒体或认证等外部边界。

需要等待、滚动、弹窗、输入、权限、分页和状态断言范式时，读取 [references/xcuitest-patterns.md](references/xcuitest-patterns.md)。

## 分层验证

### 1. 编译和启动

- 为兼容的模拟器编译 Workspace Scheme。
- 诊断启动问题时，使用 `simctl` 安装构建出的 `.app`。
- 通过 Bundle Identifier 启动，并确认返回了 PID。
- 预期根页面不可见时，截取屏幕或检查模拟器元素层级。
- 区分安装或启动失败，以及 UI 被阻塞、位于屏幕外、被弹窗覆盖、等待权限或启动后立即退出等情况。
- 区分 CoreSimulator 运行时与 Simulator 图形窗口：XCUITest、`simctl io` 和 xcresult 截图可以在没有可见窗口时工作，因此“能截图”不能证明用户看得到窗口。
- 可视验证时，无论设备原先是 Shutdown 还是 Booted，都要主动打开并激活 Simulator；测试期间和结束后不得自动关闭该设备。

#### 可视模式与无头模式

- **可视模式（默认）：** 本地人工观察和交互验证。执行器优先选择 Simulator 当前窗口设备，再使用同一个动态 UUID 启动设备、打开 Simulator、置前窗口并运行测试。若检测到窗口设备与测试 Destination 不一致，必须在测试开始前失败，不能静默操作另一台设备。
- **无头模式：** 只用于 CI 或用户明确不需要观看的场景。通过 `--headless` 启用，并在结果中明确标注窗口没有打开。

如果可视模式下自动化可以截图和点击，但用户看不到画面，先检查 Simulator 是否存在可见设备窗口、窗口是否位于其他桌面空间、是否被最小化，以及测试 UUID 是否与窗口设备一致。不要先修改业务代码。

#### 并行 Clone 与人工观察

允许 Xcode 根据 Scheme 设置并行运行测试和创建 `Clone N of <Simulator>`。不得仅因为出现 Clone 就关闭并行；每个 Clone 是独立测试 Worker，测试结束后通常由 Xcode 清理。

可视验证必须让页面在稳定断言通过后停留，不能只让页面一闪而过：

1. 先用 `waitForExistence` 或状态谓词确认页面加载完成；
2. 断言该页面的关键内容和交互状态；
3. 保存带名称的截图附件；
4. 调用通用观察检查点，中间页面默认停留 2 秒，最终页面默认停留 5 秒；
5. 最终观察必须发生在 `tearDown` 或 `app.terminate()` 之前。

观察停留只服务于人工查看，不得作为加载等待、测试同步或正确性依据。页面未满足断言时必须立即失败，不能先停留再判定。并行运行时，各 Clone 分别执行相同的检查点和停留；最终结果仍以 XCTest 断言和 xcresult 为准。

使用 `IOS_FLOW_OBSERVATION_ENABLED`、`IOS_FLOW_STEP_OBSERVE_SECONDS` 和 `IOS_FLOW_FINAL_OBSERVE_SECONDS` 控制停留。测试 Target 应复用 [references/xcuitest-patterns.md](references/xcuitest-patterns.md) 中的 `FlowObservation`，不要在各测试中散落无条件 `sleep`。

### 2. 单元测试和解码测试

在不依赖 UI 时序的情况下，测试领域数据修改规则、响应解码、分页终止条件、权限门禁和状态转换。

### 3. 网络契约测试

当功能调用后端时，使用自定义 `URLProtocol` 或仓库已有的传输层测试边界拦截请求，并断言：

- 精确接口路径；
- HTTP 方法；
- 必需字段和禁止字段；
- 后端区分数字与字符串时的准确表示；
- 页码和筛选参数；
- 响应解码和后端错误传递。

演示环境流程通过，不能证明真实账户请求正确。

### 4. XCUITest 用户旅程

以干净状态启动应用，通过真实 UI 进入确定性测试环境，执行用户实际会进行的点击、输入、滑动、弹窗和导航操作。

使用 `waitForExistence`、状态谓词和有限次数的语义滚动。除非外部动画没有任何可观察的完成信号，否则不得使用固定 `sleep`。除验证坐标型控件且确实无法提供无障碍元素之外，不得点击绝对坐标。

断言中间检查点，不能只验证最终页面。数据修改后，断言变化后的标题或数值；需要验证持久化时，退出后重新进入；对只读角色，验证被禁止的操作不存在。

可视模式下，每个主要页面断言成功后调用 `FlowObservation.checkpoint`，最终业务页面调用 `FlowObservation.finalCheckpoint`。观察辅助方法不得影响断言结果；关闭观察后，同一测试必须保持相同行为和结果。

### 5. 无障碍与布局

新增或修改 UI 后，运行相关的 `XCUIAccessibilityAuditType` 检查。至少考虑：

- `.dynamicType`
- `.textClipped`
- `.hitRegion`
- `.sufficientElementDescription`

从 xcresult 导出问题说明、应用截图和元素截图。修复布局或无障碍语义，不得大范围屏蔽真实问题。只有具备专用测试、并有证据表明属于 Xcode 误报时，才允许添加范围严格的过滤规则。

### 6. 回归范围

按以下顺序运行：

1. 新增或修改的单元测试与契约测试；
2. 新增或修改的 UI 旅程；
3. 直接相关的现有旅程；
4. 相关无障碍审计；
5. 当改动涉及共享导航、应用上下文、Gateway 协议、设计系统、本地化、持久化或跨功能逻辑时，运行 Scheme 全量测试。

全量测试失败时，检查 xcresult 并修复根因。先重新运行失败测试，再重新执行完整范围。不得把部分测试数量报告成完成结果。

## 命令执行器

运行指定用户旅程：

```bash
~/.codex/skills/ios-simulator-flow-verifier/scripts/verify_ios_flow.sh \
  --workspace /absolute/path/App.xcworkspace \
  --scheme App \
  --only-testing AppUITests/AppJourneyTests/testChangedFlow
```

重复传入 `--only-testing` 可运行多个指定测试；使用 `--full` 运行 Scheme 全量测试；每个确定性应用启动参数分别传入一次 `--launch-arg`；使用 `--dry-run` 只检查解析后的命令和模拟器，不实际执行。执行器默认使用 `--visible`，只有 CI 或用户明确要求时才使用 `--headless`。使用 `--observe-seconds` 和 `--final-observe-seconds` 调整人工观察时长；它们不改变并行测试设置。

执行器默认把 DerivedData 和 xcresult 产物写入 `/tmp/ios-simulator-flow-verifier`，并输出选中的模拟器、命令、结果路径和 xcresult 摘要。

## 失败分类

修改代码之前，先对问题分类：

- **编译失败：** 编译器、链接器、依赖包、签名或生成文件问题。
- **安装失败：** 产品无效、Runtime 不可用、模拟器状态过期或 Bundle 不匹配。
- **启动失败：** 进程退出、Scene 或配置崩溃、缺少运行时密钥或 Framework。
- **控件定位失败：** 标识符错误、元素尚未加载、内容位于屏幕外或属于不同的无障碍容器。
- **流程失败：** 导航、状态、权限、数据修改或持久化不正确。
- **契约失败：** 请求路径或载荷与参考后端契约不一致。
- **审计失败：** 文字裁切、点击区域、无障碍标题、对比度或动态字体问题。
- **基础设施警告：** 模拟器或 Xcode 出现警告但测试仍正常执行；不得误报成应用失败。

使用 `xcresulttool get test-results summary`、`get test-results activities` 和 `export attachments --only-failures`。编辑 UI 之前，检查完整问题文本、应用截图和元素截图。

## 完成门槛

必须报告：

- 运行时动态选择的模拟器型号、系统版本和 UUID；
- 验证使用可视模式还是无头模式；可视模式下确认测试开始前基础窗口设备与 Destination UUID 一致；
- 是否并行创建 Clone，以及每个主要页面和最终页面的观察停留时长；
- 并行测试时，从 xcresult 报告每个 Clone Worker 的设备名称和临时 UUID；
- 已验证的用户旅程及中间检查点；
- 指定测试和全量测试的通过、失败、跳过数量；
- xcresult 绝对路径；
- 手动重新启动时的安装、启动结果和 PID；
- 无障碍审计结果；
- 真实后端契约覆盖情况，或者明确说明有效凭据或外部服务尚未验证；
- 相机、麦克风、推送、StoreKit、实时多用户、生产凭据等仍需真机或人工检查的项目。

如果只通过了编译、静态审查、截图、演示数据或单一成功流程，不得宣称“逻辑正确”。
