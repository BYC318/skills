# iOS 模拟器流程验证 Skill 使用教程

`ios-simulator-flow-verifier` 用于在修改 iOS 代码后，通过真实 Simulator、XCTest/XCUITest 和 xcresult 证据验证业务流程。它不会把“编译成功”或“能够截图”当成功能正确。

这是通用型 Skill。验证范围由当前代码改动、验收条件和项目现有测试体系决定，不预设具体业务页面、第三方 SDK 或专项容器。项目出现特殊能力时，在当前任务中按实际实现补充测试，不修改通用 Skill 的默认验收范围。

## 适用范围

- Swift、SwiftUI、UIKit 或混合项目
- `.xcworkspace` 和 `.xcodeproj`
- 页面跳转、按钮、表单、列表、弹窗和状态切换
- 网络请求、数据解码、权限、角色和持久化
- “编译成功但运行不起来”或“自动化能操作但看不到模拟器”的诊断

## 文件说明

```text
ios-simulator-flow-verifier/
├── SKILL.md                         Skill 执行规范
├── README.md                        使用教程
├── agents/openai.yaml               Codex 展示和默认提示词
├── scripts/verify_ios_flow.sh       模拟器测试执行器
└── references/xcuitest-patterns.md  XCUITest 和契约测试通用范式
```

## 前置条件

使用前确认：

1. 已安装 Xcode 和目标 iOS Simulator Runtime。
2. `xcode-select -p` 指向要使用的 Xcode。
3. 项目存在可共享 Scheme。
4. 项目已经配置 Unit Test 或 UI Test Target；没有时可让 Codex 创建。
5. UI 流程中的关键控件具有稳定的 `accessibilityIdentifier`。
6. 需要账号或固定数据的流程具备测试账号、Mock、Fixture 或依赖注入边界。

## 最简单的使用方式

在 Codex 中直接输入：

```text
使用 $ios-simulator-flow-verifier 验证我刚修改的功能。
请先读取项目规则和代码改动，整理验收条件，补充必要测试，
然后以可视模式在模拟器点击完整业务流程，最后报告 xcresult 和剩余风险。
```

验证指定业务流程：

```text
使用 $ios-simulator-flow-verifier 验证个人资料保存。
在模拟器进入个人中心，修改昵称并保存，退出后重新进入，
确认新昵称仍然存在。必须让我看到点击过程。
```

## 验证流程

Skill 会按下面的证据链工作：

```text
读取仓库规则和代码改动
→ 明确可观察的验收条件
→ 检查或补充测试边界
→ 构建项目
→ 启动并显示指定模拟器
→ 安装、启动应用
→ 点击真实业务流程
→ 验证中间状态和最终结果
→ 必要时验证刷新、重启和持久化
→ 运行契约测试及无障碍审计
→ 输出 xcresult、测试数量和未覆盖风险
```

## 可视模式

可视模式是本地执行的默认模式。它会：

- 优先选择 Simulator 当前窗口设备；
- 启动同一个动态 UUID 对应的设备；
- 打开并置前 Simulator；
- 检查屏幕上是否存在 Simulator 窗口；
- 测试开始前检查基础窗口设备 UUID 是否与测试 Destination 一致；
- 在页面断言成功后提供可配置的人工观察停留；
- 测试结束后保持 Simulator 打开。

命令示例：

```bash
~/.codex/skills/ios-simulator-flow-verifier/scripts/verify_ios_flow.sh \
  --workspace /绝对路径/App.xcworkspace \
  --scheme App \
  --visible \
  --only-testing AppUITests/AppJourneyTests/testChangedFlow
```

`--visible` 可以省略，因为它是默认模式。

如果检测到 Simulator 进程存在但没有屏幕窗口，或者当前窗口设备与测试 UUID 不一致，脚本会在测试开始前停止，避免自动化静默操作另一台设备。

## 并行 Clone 与页面停留

Xcode 开启并行测试时，可能创建多个 `Clone N of iPhone` 窗口。每个 Clone 是独立的测试 Worker，并拥有临时 UUID，这属于正常行为；Skill 不会禁止并行 Clone。基础设备一致性只在并行测试开始前校验，测试结果从 xcresult 分别报告各 Clone Worker。

为了让测试过程可观察，UI Test Target 需要复用 `references/xcuitest-patterns.md` 中的 `FlowObservation`：

```swift
let page = app.otherElements["feature.root"]
XCTAssertTrue(page.waitForExistence(timeout: 8))
XCTAssertTrue(app.staticTexts["feature.title"].exists)
FlowObservation.checkpoint("功能页面", in: self)

app.buttons["feature.submit"].tap()
let result = app.otherElements["result.success"]
XCTAssertTrue(result.waitForExistence(timeout: 8))
FlowObservation.finalCheckpoint("成功结果页", in: self)
```

默认停留时间：

- 每个主要中间页面：2 秒；
- 最终结果页面：5 秒。

调整时长：

```bash
verify_ios_flow.sh \
  --workspace App.xcworkspace \
  --scheme App \
  --observe-seconds 3 \
  --final-observe-seconds 8 \
  --full
```

停留只发生在页面断言成功后，用于人工查看，不参与加载等待和正确性判定。测试失败时不会为了展示而继续停留；最终停留必须放在 `tearDown` 或 `app.terminate()` 之前。

## 无头模式

无头模式用于 CI，或者用户明确不需要观看过程的场景：

```bash
~/.codex/skills/ios-simulator-flow-verifier/scripts/verify_ios_flow.sh \
  --project /绝对路径/App.xcodeproj \
  --scheme App \
  --headless \
  --full
```

无头模式下，XCUITest、`simctl` 截图和 xcresult 仍然能够工作，但不会主动打开 Simulator 窗口。

## 指定测试

下面使用 `verify_ios_flow.sh` 作为命令简称；如果没有把脚本目录加入 `PATH`，请替换成完整路径：

```text
~/.codex/skills/ios-simulator-flow-verifier/scripts/verify_ios_flow.sh
```

运行一个测试：

```bash
verify_ios_flow.sh \
  --workspace App.xcworkspace \
  --scheme App \
  --only-testing AppUITests/ProfileJourneyTests/testSaveProfile
```

运行多个测试时重复传入 `--only-testing`：

```bash
verify_ios_flow.sh \
  --workspace App.xcworkspace \
  --scheme App \
  --only-testing AppTests/ProfileStoreTests/testSave \
  --only-testing AppUITests/ProfileJourneyTests/testSaveProfile
```

运行 Scheme 中的全部测试：

```bash
verify_ios_flow.sh \
  --workspace App.xcworkspace \
  --scheme App \
  --full
```

## 其他常用参数

```text
--workspace PATH      Xcode Workspace 路径
--project PATH        Xcode Project 路径
--scheme NAME         要测试的共享 Scheme
--device-id UUID      指定可用模拟器
--device-name NAME    优先选择指定模拟器型号
--only-testing ID     指定测试，可重复传入
--full                运行完整 Scheme 测试
--derived-data PATH   指定 DerivedData 路径
--result PATH         指定 xcresult 路径
--launch-arg VALUE    记录测试需要的启动参数，可重复传入
--visible             可视模式，默认值
--headless            无头模式
--observe-seconds N   中间页面人工观察秒数，默认 2
--final-observe-seconds N 最终页面人工观察秒数，默认 5
--no-observation      关闭人工观察停留
--verbose             显示完整 xcodebuild 日志
--dry-run             只解析设备和命令，不执行测试
```

查看最新参数：

```bash
~/.codex/skills/ios-simulator-flow-verifier/scripts/verify_ios_flow.sh --help
```

## 先用 dry-run 检查

首次接入项目时，建议先解析命令：

```bash
verify_ios_flow.sh \
  --workspace /绝对路径/App.xcworkspace \
  --scheme App \
  --only-testing AppUITests/AppJourneyTests/testChangedFlow \
  --dry-run
```

重点确认：

- Workspace 或 Project 路径正确；
- Scheme 正确；
- 模拟器型号和 UUID 符合预期；
- `-only-testing` 标识符正确；
- xcresult 和 DerivedData 路径可写。

## 为 UI 增加稳定标识符

SwiftUI：

```swift
Button("保存") {
    save()
}
.accessibilityIdentifier("profile.save")
```

UIKit：

```swift
saveButton.accessibilityIdentifier = "profile.save"
```

XCUITest：

```swift
let saveButton = app.buttons["profile.save"]
XCTAssertTrue(saveButton.waitForExistence(timeout: 5))
XCTAssertTrue(saveButton.isHittable)
saveButton.tap()
```

建议使用带业务命名空间的稳定标识符，例如：

```text
welcome.enter
profile.save
profile.nickname
order.submit
web.page.ready
web.retry
```

不要把绝对屏幕坐标作为主要选择器，也不要只依赖会变化或本地化的标题。

## 测试数据设计

UI 测试应使用确定性测试环境：

- 启动参数进入 UI 测试模式；
- 使用 Fixture、Mock Gateway 或测试服务器提供固定数据；
- 只替换网络、支付、认证等外部边界；
- 保留生产页面、路由、Store 和业务用例；
- Fixture 必须支持保存、关注、切换等真实状态修改；
- 需要验证持久化时，退出页面或重启应用后重新检查。

示例启动方式：

```swift
let app = XCUIApplication()
app.launchArguments = ["--ui-testing", "--demo"]
app.launchEnvironment["ANIMATIONS_DISABLED"] = "1"
app.launch()
```

脚本的 `--launch-arg` 会记录参数并提醒测试代码配置 `XCUIApplication.launchArguments`，不会绕过测试代码直接注入参数。

## xcresult 结果检查

默认结果目录：

```text
/tmp/ios-simulator-flow-verifier/results/
```

查看摘要：

```bash
xcrun xcresulttool get test-results summary --path Test.xcresult
```

查看指定测试活动：

```bash
xcrun xcresulttool get test-results activities \
  --path Test.xcresult \
  --test-id 'Target/Suite/testName()'
```

导出失败附件：

```bash
xcrun xcresulttool export attachments \
  --path Test.xcresult \
  --output-path /tmp/test-failures \
  --only-failures
```

失败时同时检查：

- `Complete Issue Description.txt`
- 应用截图
- 元素截图
- 测试活动和控制台日志
- 崩溃日志或启动失败原因

## 如何判断验证完成

最终报告至少应包含：

- 模拟器型号、系统版本和动态 UUID；
- 可视模式或无头模式；
- 基础 Destination UUID、并行 Clone 数量、各 Worker 临时 UUID 以及页面观察停留时长；
- 验证过的用户旅程和中间检查点；
- 通过、失败和跳过测试数量；
- xcresult 绝对路径；
- 应用安装、启动及 PID；
- 无障碍审计结果；
- 网络契约或真实后端覆盖情况；
- 仍需真机或人工验证的能力。

只有编译成功、App 启动、自动化截图或单一成功流程通过时，不能宣称业务逻辑已经完整正确。

## 常见问题

### 自动化可以点击和截图，但肉眼看不到模拟器

原因通常是 CoreSimulator 已经无头启动，但 Simulator 没有设备窗口，或者窗口设备与测试设备不同。

处理方式：

```text
使用默认 --visible 模式；
不要只执行 simctl boot；
确认输出中的窗口 UUID 与测试 UUID 一致；
检查窗口是否被最小化或位于其他桌面空间。
```

### 编译成功但 App 没有启动

依次检查：

1. Scheme 是否包含正确 App Target；
2. Bundle Identifier 是否与启动命令一致；
3. 构建产品是否安装成功；
4. App 是否启动后立即崩溃；
5. 是否缺少运行时密钥、配置或动态 Framework；
6. xcresult 和模拟器日志是否记录了退出原因。

### 找不到按钮

检查：

- 是否配置了正确的 `accessibilityIdentifier`；
- 元素是否尚未加载；
- 元素是否在屏幕外；
- 是否被弹窗、键盘或 Sheet 覆盖；
- 控件是否处于不同的无障碍容器；
- 是否错误依赖了本地化标题。

### 测试偶发失败

不要首先增加固定 `sleep`。优先使用：

- `waitForExistence`
- `NSPredicate` 状态等待
- 有限次数滚动
- 明确的加载完成标识
- 确定性测试数据
- 禁用非必要动画

## 在项目中规定每次改动都验证

可以在项目 `AGENTS.md` 增加：

```markdown
## iOS 模拟器验收

修改 Swift、SwiftUI、UIKit、导航、状态、网络、持久化、权限
或其他用户可观察行为后，必须使用 `$ios-simulator-flow-verifier` 验证。

本地默认使用可视模式，让用户看到模拟器点击和跳转过程。
只有 CI 或用户明确要求时才能使用无头模式。

不得只以编译成功、截图或单一成功流程作为完成依据。
最终必须报告测试范围、结果数量、模拟器 UUID、xcresult 路径和未覆盖风险。
```

## 能力边界

以下能力可能仍需真机或外部环境：

- 相机和部分媒体采集能力
- 蓝牙、NFC 和特定硬件
- APNs 生产推送
- 真实 StoreKit 支付链路
- 第三方登录真实回调
- 多设备实时通信
- 生产证书、账号和服务端权限

Skill 会把这些内容列为未覆盖风险，不会虚假报告已经完成。
